#include <iostream>
#include <stdio.h>
#include <conio.h>
#define NMAX 10


using namespace std;

int main( void )
{
    char a[NMAX];
    int n=NMAX;
    for( int i=0; i < n; i++ )
    {
        cout<<"Int a char: ";
        a[i] = getch();
        cout<<a[i]<<endl;
    }

    return 0;
}
