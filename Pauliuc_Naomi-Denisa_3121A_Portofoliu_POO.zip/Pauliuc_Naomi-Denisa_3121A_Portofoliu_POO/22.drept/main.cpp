#include <iostream>
#include <math.h>

using namespace std;

class dreptunghi
{
    double Lung, lat;
public:
    void seteaza_dimen(double, double );
    double arata_Lung()
    {
        return Lung;
    }
    double arata_Lat()
    {
        return lat;
    }
    double calcul_arie()
    {
        return Lung*lat;
    }
};
void dreptunghi::seteaza_dimen( double L, double l )
{
    Lung=L;
    lat=l;
}
int main()
{
    dreptunghi a;
    double l1, l2;
    cout<<"Lungime=";
    cin>>l1;
    cout<<"Latime=";
    cin>>l2;
    a.seteaza_dimen( l1, l2);
    cout<<"Dim. drept. sunt: ";
    cout<<a.arata_Lung()<<" si "<<a.arata_Lat()<<'\n';
    cout<<"Aria drept.: "<< a.calcul_arie() <<'\n';
    cout<<"Dimens: "<<sizeof( a )<<'\n';
    return 0;
}
