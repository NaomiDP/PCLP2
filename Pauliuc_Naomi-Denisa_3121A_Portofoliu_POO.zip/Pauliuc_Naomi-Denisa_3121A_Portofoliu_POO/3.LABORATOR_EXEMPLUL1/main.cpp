#include <iostream>
using namespace std;

int main( void )
{
    cerr << "cerr"<<endl; //INSERARE IN CERR
    clog << "clog"<<endl; //INSERARE IN CLOG
    cout << "cout"<<endl; //INSERARE IN COUT
    return 0;
}
