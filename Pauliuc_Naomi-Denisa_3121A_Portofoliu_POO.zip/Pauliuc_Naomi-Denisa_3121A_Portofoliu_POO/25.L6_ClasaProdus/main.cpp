#include <iostream>
#define NMAX 100

using namespace std;

class Produs
{
    int a[50], n, rez;
public:
    Produs(int _a[], int _n);
    void calcprodus();
    void print();
};

Produs::Produs(int _a[], int _n)
{
    n=_n;
    //rez=1;
    for(int i=0; i<n; i++)
    {
        a[i]=_a[i];
    }
}

void Produs::calcprodus()
{
    rez=1;
    for(int i=0; i<n; i++)
    {
        rez=rez*a[i];
    }
}

void Produs::print()
{
    cout<<"Sirul introdus este: ";
    for (int i=0; i<n; i++)
    {
        if (i<n-1)
            cout<<a[i]<<", ";
        else
            cout<<a[n-1]<<endl;
    }
    cout<<"Produsul este: "<<rez<<endl;
}

int main()
{
    //int sir[]= {2,3,4};
    int n, x[NMAX];
    cout<<"Int nr de elem: ";
    cin>>n;
    for (int i=0; i<n; i++)
    {
        cout<<"x["<<i<<"] = ";
        cin>>x[i];
    }
    /*cout<<"Vectorul intodus este: ";
    for (int i=0;i<n;i++)
    {
        if (i<n-1)
            cout<<x[i]<<", ";
        else cout<<x[n-1];
    }*/
    Produs p(x,n);//cosntructorul
    p.calcprodus();//calculeaza
    p.print();//afiseaza
    return 0;
}
