#include <stdio.h>
#include <stdlib.h>
#define square( x ) ( ( x ) * ( x ) )

int main()
{
    printf("12^2 = %d", square(12));
    return 0;
}
