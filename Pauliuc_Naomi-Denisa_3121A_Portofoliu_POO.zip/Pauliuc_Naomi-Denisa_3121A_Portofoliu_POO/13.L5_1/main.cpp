#include <iostream>

using namespace std;

int main()
{
    int x=0;
    int &y= x;
    x=2;
    y=7;
    cout <<"x = "<<x<<endl; //x = 7
    cout <<"y = "<<y;
}
