#include <iostream>

using namespace std;

class Complex
{
    double re, im;
public:
    friend ostream& operator<<( ostream &c, Complex &str );
    friend istream& operator>>( istream &c, Complex &str );
};

ostream& operator<<( ostream &c, Complex &str )
{
    c << "\nNr: " << str.re << " +i " << str.im;
    return c;
}

istream& operator>>( istream &c, Complex &str )
{
    cout << "Introdu nr. complex (re, im ): " << endl;
    cout<<"Partea reala: ";
    c >> str.re;
    cout<<"\nPartea imaginara: ";
    c >> str.im;
    return c;
}

int main( void )
{
    Complex A;
    cin >> A;
    cout << A << endl;
    return 0;
}
