#include <iostream>

using namespace std;

class Complex
{
    double re, im;
public:
    Complex( double _re=0, double _im=0): re(_re), im(_im)
    {
    }
    Complex& operator+(Complex &y)
    {
        this->re += y.re;
        this->im += y.im;
        return *this;
    }
    friend ostream& operator<<(ostream &c, Complex &y);
};

ostream& operator<<(ostream &c, Complex &y)
{
    c<<"("<<y.re<<" +i "<<y.im<<") ";
    return c;
}

template<class T>
T Suma(T x, T y)
{
    T rez;
    rez=x+y;
    return rez;
}

int main()
{
    cout<<"TEMPLATE"<<endl;
    Complex r, a(1, 2), b(3, 4);
    r=Suma(a,b);
    cout<<"Suma = "<<r<<endl;
    return 0;
}
