#include <iostream>

using namespace std;

class Suma
{
    int a[100], n, sum;
public:
    Suma (int _a[], int _n);
    void CalcSuma(void);
    void print(void);
};

//constructor
Suma::Suma (int _a[], int _n)
{
    n=_n;
    sum=0;
    for(int i=0; i<n; i++)
    {
        a[i]=_a[i];
    }
}
//functia de calcul
void Suma::CalcSuma(void)
{
    sum=0;
    for(int i=0;i<n;i++)
    {
        sum=sum+a[i];
    }
}

//functia afisare
void Suma::print(void)
{
    cout<<"Sirul introdus: ";
    for(int i=0;i<n;i++)
    {
        cout<<a[i]<<",";
    }
    cout<<"\n\nSuma este: "<<sum<<endl;
}

int main()
{
    int sir[]={2,4,6};
    Suma s(sir,3); //constructorul
    s.CalcSuma();//calculeaza suma
    s.print();//afisare
    return 0;
}
