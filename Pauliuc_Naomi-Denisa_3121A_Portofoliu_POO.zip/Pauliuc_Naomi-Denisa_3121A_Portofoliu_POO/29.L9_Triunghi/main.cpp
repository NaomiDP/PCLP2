#include <iostream>

using namespace std;
#include <math.h>
#include <stdio.h>
#include <string.h>

// Clasa FIGURA GEOMETRICA - generica

class FigGeom
{
protected:
    char nume[ 80 ];
public:
    FigGeom( char *_nume = "{ nedefinita }" );
    double Arie( void );
    double Perimetru( void );
    char* TipFigura( void );
};

FigGeom::FigGeom( char *_nume )
{
    strcpy( nume, _nume );
}

double FigGeom::Arie( void )
{
    return 0.0;
}

double FigGeom::Perimetru( void )
{
    return 0.0;
}

char* FigGeom::TipFigura( void )
{
    return nume;
}

//Clasa TRIUNGHI - derivata din FigGeom

class Triunghi : public FigGeom
{
public:
    float x,y,z;
    void set_lat(float, float, float);
    Triunghi( char *_nume = "{ TRIUNGHI }" );
    double Arie( void );
    double Perimetru( void );

//char* TipFigura( void ); // NU ESTE NECESARA
};

void Triunghi::set_lat(float _x, float _y, float _z)
{
    x=_x;
    y=_y;
    z=_z;
}

Triunghi::Triunghi( char *_nume ): FigGeom( _nume )
{
    // Constructorul pt. CB
    /* fara alte operatii ... deocamdata! */
}

double Triunghi::Arie( void )
{
    float aria,semi;
    semi=(x+y+z)/2;
    aria=sqrt(semi*(semi-x)*(semi-y)*(semi-z));
    return aria;
}

double Triunghi::Perimetru( void )
{
    float p;
    p=x+y+z;
    return p;
}


int main()
{
    cout << "[ START ] Studiul mostenirii" << endl;
    FigGeom fg1;
    cout <<"\nArie figura " << fg1.TipFigura() << ": "
         << fg1.Arie() << endl;
    cout <<"Perimetru figura " << fg1.TipFigura() << ": "
         << fg1.Perimetru() << endl;
    Triunghi tr1;
    tr1.set_lat(11, 7, 5);
    cout <<"\nArie figura " << tr1.TipFigura() << ": "
         << tr1.Arie() << endl;
    cout <<"Perimetru figura " << tr1.TipFigura() << ": "
         << tr1.Perimetru() << endl;
    cout << "\n[ END ]" << endl;
    /*
    Triunghi tr2( "TRIUNGHI Echilateral", 2, 2, 2 ) ;
     cout<<"\nArie figura " << tr2.TipFigura() << ": "
    << tr2.Arie() << endl;
    cout<<"\Perimetru figura " << tr2.TipFigura() << ": "
    << tr2.Perimetru() << endl;
    cout << "\n[ END ]" << endl;
    */
    return 0;
}
