#include <iostream>
#include <math.h>         /* atan */
#define PI 3.14159265

using namespace std;

int main ()
{
  double param, result;
  cout<< "Enter a number:";
  cin>>  param;
  result = atan (param) * 180 / PI;
  cout<< "Arctan in degrees is: " << result <<endl;
  return 0;
}
