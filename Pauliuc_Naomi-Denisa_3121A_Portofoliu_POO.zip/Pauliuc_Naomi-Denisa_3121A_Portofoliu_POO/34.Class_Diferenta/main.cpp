#include <iostream>

using namespace std;

class calcul
{
    int a[100], n, d;
public:
    calcul (int _a[], int _n);
    void Calc(void);
    void print(void);
};

//constructor
calcul::calcul (int _a[], int _n)
{
    n=_n;
    d=0;
    for(int i=0; i<n; i++)
    {
        a[i]=_a[i];
    }
}
//functia de calcul
void calcul::Calc(void)
{
    d=0;
    for(int i=0;i<n;i++)
    {
        d=d-a[i];
    }
}

//functia afisare
void calcul::print(void)
{
    cout<<"Sirul introdus: ";
    for(int i=0;i<n;i++)
    {
        cout<<a[i]<<",";
    }
    cout<<"\n\nDiferenta este: "<<d<<endl;
}

int main()
{
    int sir[]={2,4,6};
    calcul s(sir,3); //constructorul
    s.Calc();//calculeaza suma
    s.print();//afisare
    return 0;
}
