#include <iostream>
#define NMAX 100

using namespace std;

int main()
{
    int n, x[NMAX];
    cout<<"Int nr de elem: ";
    cin>>n;
    for (int i=0;i<n;i++)
        {
            cout<<"x["<<i<<"] = ";
            cin>>x[i];
        }
    cout<<"Vectorul intodus este: ";
    for (int i=0;i<n;i++)
    {
        if (i<n-1)
            cout<<x[i]<<", ";
        else cout<<x[n-1];
    }
    return 0;
}
