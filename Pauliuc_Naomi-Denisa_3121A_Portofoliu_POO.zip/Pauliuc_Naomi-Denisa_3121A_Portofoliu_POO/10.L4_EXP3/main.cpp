#include <iostream>

using namespace std;

int main( void )
{
    char c;
    while((c = cin.get()) != '\r')
        cout << "c = " << c << endl;
    return 0;
}
