#include <iostream>
#include <string.h>

using namespace std;

class myString
{
    char a[100];
    int n;
public:
    myString (char _a[], int _n);
    ~myString();
    void print(void);
    int len(void);
    int rows(void);
    int nrVoc(void);
    int nrSep(void);
    int indexOf(char s[]);
};

myString::myString (char _a[], int _n)
{
    n=_n;
    for(int i=0; i<=strlen(a); i++)
    {
        a[i]=_a[i];
    }
}

myString::~myString(){}

void myString::print(void)
{
    cout<<"Afisare functie print: \n";
    cout<<"String["<<strlen(a)<<"/100]:{"<<a<<"}"<<endl;
}

int myString::len(void)
{
    int nr=0;
    for(int i=0; i<strlen(a); i++)
    {
        nr++;
    }
    cout<<"\n\nLungimea sirului este de: "<<nr<<endl;
}

int myString::rows(void)
{
    int nr=0;
    for (int i=0; i<strlen(a); i++)
    {
        if(a[i]=='\n')
            nr++;
    }
    cout<<"\n\nNumarul de randuri este de: "<<nr+1<<endl;
}
int myString::nrVoc(void)
{
    char vocale[]="aeiouAEIOU";
    int nr=0;
    for (int i=0; i<strlen(a); i++)
    {
        if(strchr(vocale,a[i]))
            nr++;
    }
    cout<<"\n\nNumarul de vocale este de: "<<nr<<endl;
}
int myString::nrSep(void)
{
    int nr=0;
    for (int i=0; i<strlen(a); i++)
    {
        if(a[i]==' ' || a[i]==',' || a[i]=='.')
            nr++;

    }
    cout<<"\n\nNumarul de separatori este de: "<<nr<<endl;
}
int myString::indexOf(char s[])
{
    char *p;
    p = strstr (a, s);
    if (p != NULL)
    {
        cout<<"\nSirul contine subsirul introdus"<<endl;
        //cout<<"Pozitia subsirului este: "<<p<<endl;
    }
    else
        cout<<"\nSirul nu contine Subsirul introdus"<<endl;
}

int main()
{
    int n;
    char a[100]="Aceasta materie este la POO.\nTestul va dura 10 minute";
    cout<<"Afisare in main:\n\n"<<a<<"\n"<<endl;
    myString s("Aceasta materie este la POO.\nTestul va dura 10 minute", n);
    s.print();//afisare
    s.len();
    s.rows();
    s.nrVoc();
    s.nrSep();
    s.indexOf("este");
    return 0;
}
