#include <iostream>
using namespace std;

int main( void )
{
    int intNumber;
    cout << "Numar int = "; //INSERARE IN FLUX
    cin >> intNumber; //EXTRAGERE DIN FLUX
//INSERARE IN FLUX
    cout << "\nAi introdus= " << intNumber << endl;
    return 0;
}
