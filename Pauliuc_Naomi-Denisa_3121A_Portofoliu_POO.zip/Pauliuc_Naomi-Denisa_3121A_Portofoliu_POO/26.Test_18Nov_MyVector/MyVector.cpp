#include <iostream>
#include "MyVector.h"
#define NMAX 100
using namespace std;

MyVector::MyVector(int _a[], int _n)
{
    n=_n;
    suma=0;
    for(int i=0; i<n; i++)
    {
        a[i]=_a[i];
    }
}

MyVector::~MyVector(){}

void MyVector::add(int val)
{
    int m=n+1;
    for (int i=0; i<m; i++)
    {
        a[m-1]=val;
    }

}

void MyVector::val(int x)
{
    int nr=0;
    for(int i=0;i<n;i++)
    {
        if(a[i]==x)
            {cout<<"Numarul dat se afla pe pozitia "<<i<<endl;
            nr++;}
    }
    if(nr==0)
        cout<<"-1";
    else cout<<x;
}
void MyVector::del(int i)
{
    for(int j=0;j<n;j++)
    {
        if(a[j]==i)
            {cout<<a[j+1];
            j=j+1;}
        else
            cout<<a[j];
    }
}
void MyVector::sum()
{
    suma=0;
    for(int i=0;i<n;i++)
    {
        suma=suma+a[i];
    }
    cout<<"Suma elementelor este:"<<suma<<endl;
}
void MyVector::print()
{
    int nr=0;
    while(i<=n)
    {
        nr++;
        i++;
    }
    cout<<"[Vector[ "<<nr<<"/"<<n<<"]:{";
    for (int i=0; i<n; i++)
    {

        if (i<n-1)
            cout<<a[i]<<", ";
        else
            cout<<a[n-1]<<"}"<<endl;
    }

}
void MyVector::len()
{
    int nr=0;
    for(int i=0;i<n;i++)
    {
        nr++;
    }
    cout<<"Vectorul are "<<nr<< "elemente"<<endl;
}
