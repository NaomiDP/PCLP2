#include <iostream>
#include "MyVector.h"
#define NMAX 100
using namespace std;


int main()
{
    int n, val, x, i,v[NMAX];
    cout<<"Introduceti un numar";
    cin>>n;
    for (int i=0; i<n; i++)
    {
        cout<<"v["<<i<<"] = ";
        cin>>v[i];
    }
    //cout<<"Introduceti numarul de emelente din sir: ";
    //cin>>n;
    MyVector s(v, n);
    s.add(5);
    s.print();
    s.val(3);
    s.del(i);
    s.sum();
    s.print();
    s.len();
    return 0;
}
