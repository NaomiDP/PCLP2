#ifndef MYVECTOR_H_INCLUDED
#define MYVECTOR_H_INCLUDED

class MyVector
{
    int n, x, i, v, a[100], suma;
public:
    MyVector(int _a[], int _n);
    ~MyVector();
    void add(int v);
    void val(int x);
    void del(int i);
    void sum();
    void print();
    void len();
};

#endif // MYVECTOR_H_INCLUDED
