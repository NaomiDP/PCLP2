#include <iostream>

using namespace std;

void f1( int a )
{
    a = 2;
    cout<<"Functie f1: "<<a<<endl;
}

void f2( int *a )
{
    *a = 2;
    cout<<"Functie f2: "<<*a<<endl;
}

void f3( int &a )
{
    a = 2;
    cout<<"Functie f3: "<<a<<endl;
}

int main()
{
    int x=0;
    int &y= x;
    x=2;
    y=3;
    cout <<"x = "<<x<<endl;
    cout <<"y = "<<y<<"\n\n";

    f1( x );
    cout<<"Main: "<<x<<"\n\n";

    f2( &x );
    cout<<"Main: "<<x<<"\n\n";

    f3( x );
    cout<<"Main: "<<x<<"\n\n";

    return 0;
}
