#include <iostream>

using namespace std;

class MyRational
{
    int m,n;
public:
    MyRational();
    ~MyRational();
    void Set(int M, int N);
    void Print();
    float toReal();
    MyRational toRational(float x);
    int isPositive();
    MyRational Sum(MyRational b);
    MyRational Dif(MyRational b);
};

MyRational::MyRational()
{
    m=0;
    n=1;
}

MyRational::~MyRational(){}


void MyRational::Set(int M, int N)
{
    m=M;
    n=N;
}

void MyRational::Print()
{
    cout<<m<<"/"<<n<<endl;
}

float MyRational::toReal()
{
    return (float)m/n;
}

int MyRational::isPositive()
{
    if(m*n<=0)
        return 1;
    else return 0;
}

MyRational MyRational ::Sum(MyRational b)
{
    MyRational rez;
    rez.n= this->n*b.n;
    rez.m= this->n*b.m + this->m*b.n;
    return rez;
}

MyRational MyRational ::Dif(MyRational b)
{
    MyRational rez;
    rez.n= this->n*b.n;
    rez.m= this->n*b.m - this->m*b.n;
    return rez;
}

int main()
{
    MyRational x,y,re;
    x.Set(3,2);
    cout<<"Fractia: ";
    x.Print();
    cout<<"\nNr real: "<<x.toReal()<<endl;
    if(x.isPositive()==1)
        cout<<"\nNr este poz"<<endl;
    else
        cout<<"\nNr este poz"<<endl;
    y.Set(4,5);
    cout<<"Fractia: ";
    y.Print();
    cout<<"\nNr real: "<<y.toReal()<<endl;
    re=x.Sum(y);
    cout<<"\nSuma fractiilor este: "<<y.toReal()<<endl;
    re.Print();
    re=x.Dif(y);
    cout<<"\nDif fractiilor este: "<<y.toReal()<<endl;
    re.Print();

    return 0;
}
