#include <iostream>

using namespace std;

int main()
{
    cout.put('H').put('i').put('!').put('\n');
    cout.put('\n').put('H').put('e').put('l').put('l').put('o').put('!').put('\n');
    return 0;
}
