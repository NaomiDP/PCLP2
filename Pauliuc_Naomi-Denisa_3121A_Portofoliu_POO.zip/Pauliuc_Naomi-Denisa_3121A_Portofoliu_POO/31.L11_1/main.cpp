#include <iostream>

using namespace std;

class T
{
    int a, b;
public:
    schimba(int a, int b);
};

template <class T>
void schimba(T &a, T &b)
{
    T tmp = a;
    a = b;
    b = tmp;
    cout<<a<<"\t"<<b;
}


int main()
{
    int x=1, y=3;
    cout << "Hello world!" << endl;
    schimba(x,y);
    return 0;
}
