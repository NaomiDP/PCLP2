#include <iostream>

using namespace std;

int main()
{
    int x;

    cout<<"Introduceti un numar: ";
    cin>>x;
    cout<<"\n\n";

    const int *p = &x;
    int * const a = &x;

    cout<<"p = "<<*p<<endl;
    cout<<"a = "<<*a;

    return 0;
}
