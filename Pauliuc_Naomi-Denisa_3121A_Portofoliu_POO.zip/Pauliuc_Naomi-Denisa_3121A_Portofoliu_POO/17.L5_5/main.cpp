#include <iostream>

using namespace std;

/*int main()
{
    char str[100];

    cout << "Enter a string: ";
    cin.get(str, 100);

    cout << "You entered: " << str << endl;

    return 0;
}*/

int main()
{
    // Declaring a string object
    string str;

    cout << "Enter a string: ";
    getline(cin, str);

    cout << "You entered: " << str << endl;

    return 0;
}
