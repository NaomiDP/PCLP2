// Laboratorul2  23.10.2020  16:00-18:00

#include <iostream>
#include <math.h>
using namespace std;


class myComplex{
    double real, imag, result1, result2;
public:
    void setData(double a, double b){
        real = a;
        imag = b;
    }

void print( ){

    cout << "\nNumar complex: ";
    cout << real << (imag>=0?" + ":" ")<<imag<<"j"<<endl;
}
    void addition(myComplex z1, myComplex z2){
        cout << "\nAdunare:";
        real = z1.real + z2.real;
        imag = z1.imag + z2.imag;}

    void subtraction(myComplex z1, myComplex z2){
        cout << "\nScadere:";
        real = z1.real - z2.real;
        imag = z1.imag - z2.imag;}

    void multiplication(myComplex z1, myComplex z2){
        cout << "\nInmultire:";
        real = z1.real * z2.real - z1.imag * z2.imag;
        imag = z1.real * z2.imag + z1.imag * z2.real;}

    void division(myComplex z1, myComplex z2){
        cout << "\nImpartire:";
        real = (z1.real*z2.real + z1.imag*z2.imag)/(z2.real*z2.real + z2.imag*z2.imag);
        imag = (z2.real*z1.imag - z1.real*z2.imag)/(z2.real*z2.real + z2.imag*z2.imag);
    }

    void modulus(myComplex z1, myComplex z2){
        cout << "\nModul:";
        real = sqrt(z1.real*z1.real + z1.imag*z1.imag);
        imag = sqrt(z2.real*z2.real + z2.imag*z2.imag);
    }

    void argument(myComplex z1, myComplex z2){
        cout << "\nArgumentul:";
        result1 = atan(z1.imag/z1.real);
        cout<< "\nArg1 = " << result1 <<endl;
        result2 = atan(z2.imag/z2.real);
        cout<< "Arg2 = " << result2 <<endl;
    }
};

int main()
{

    myComplex ob1, ob2, ob3, ob4, ob5, ob6, ob7, ob8;
    ob1.setData(5, -3);
    cout<< "Numarul 1 ";
    ob1.print();

    ob2.setData(2, 3);
    cout<< "\nNumarul 2 ";
    ob2.print();

    ob3.addition(ob1, ob2);
    ob3.print();

    ob4.subtraction(ob1, ob2);
    ob4.print();

    ob5.multiplication(ob1, ob2);
    ob5.print();

    ob6.division(ob1, ob2);
    ob6.print();

    ob7.modulus(ob1, ob2);
    ob7.print();

    ob8.argument(ob1, ob2);
    //ob8.print();

    return 0;
}
