#include <stdio.h>
#include <stdarg.h>

//Sorteaza numerele dintr-o lista de parametrii terminata cu 0
void Sort(char * msg, ...)
{
    va_list ap;
    va_start(ap, msg);
    int arg;
    int v[100];
    int i, j, temp, n = 0;
    printf("\n Message = %s", msg);
    while( (arg = va_arg(ap, int)) !=0 )
    {
        v[n] = arg; n++;
    }
    va_end( ap );

    //Sortarea propriuzisa
    for(i = 0; i < n-1; i++)
    for(j = i+1; j < n; j++)
        if( v[i] > v[j] )
        {
            temp = v[i];
            v[i] = v[j];
            v[j] = temp;
        }
    for(i = 0;i < n; i++)
    printf("\n v[%d] = %d",i,v[i]);
}
void main( void )
{
    //Doua exemple de apel
    Sort("Numerele sortate: ", 3, -2, 9, 8, 1, 0 );
    Sort("Numerele sortate: ", 1, 2, -3, 4, 21, 5, 12, 0);
}
