#include <iostream>

using namespace std;

class Complex
{   double re, im;
public:
    Complex (double x=0, double y=0):re(x),im(y){}
    Complex& operator+ (Complex &y)
        {
           re=re+y.re;
           im=im+y.im;

        }
    friend  ostream& operator<<( ostream &c, Complex &z )
    {
        c<<z.re;
        if(z.im >=0)
            c<<" + "<<z.im<<"i";
        else
            c<<" "<<z.im<<"i";
    }

};

template <class T>
T Suma (T x, T y)
{
    T sum;
    sum= x+y;
    return sum;

}

template <class T>

class Stiva {
    T v[100];
    int sp;
public:
    Stiva():sp(0)
    {

    }
    void push (T k)
    {
        v[sp++]=k;
    }
    void top(){
    cout<<"elementul din varful stivei este: "<<v[sp-1]<<endl;
    }
    void pop(){
    sp--;
    }
    void print(){
    cout<<"elementele stivei:\t";
    for (int i=0; i<sp;i++)
        cout<<"["<<v[i]<<" ] ";
    cout<<endl;

    }
};

int main()
{   int a=3, b=18,r1;
    double c=27.93 , d=92.1,r2;
    r1=Suma(a,b);
    r2=Suma(c,d);
    cout<<"Suma int\t"<<r1<<endl;
    cout<<"suma double\t"<<r2<<endl;
    Complex e(2,5),f(1,6),r3;
    r3=Suma(e,f);
    cout<<"suma Complex\t"<<r3<<endl;
    Stiva <int> s;
    s.push( 3);
    s.push ( 2);
    s.print();
    s.pop();
    cout<<"pop"<<endl;
    s.print();
    s.push(2355);
    s.push (21);
    s.top();
    s.print();
    Stiva <Complex> x;
    Complex z(1,7);
    x.push(z);
    x.push(e);
    x.print();
    x.push(f);
    x.push(r3);
    x.print();
    cout<<"pop"<<endl;
    x.pop();
    x.print();
    x.top();

    return 0;
}
