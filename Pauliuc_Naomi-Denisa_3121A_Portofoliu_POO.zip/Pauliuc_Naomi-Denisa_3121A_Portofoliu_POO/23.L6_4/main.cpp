#include <iostream>

using namespace std;

class String
{
    char s[80];
public:
    char& operator[]( unsigned int idx );
    friend ostream& operator<<( ostream &c, String &str )
    {
        c << str.s;
    }
};

char& String::operator[]( unsigned int idx )
{
    return idx >= 0 && idx < 80 ? s[ idx ] : s[ 0 ];
}

int main( void )
{
    String str;
    str[0] = 'P';
    str[1] = 'O';
    str[2] = 'O';
    str[3] = '\0';
    cout << str << endl;
    return 0;
}
