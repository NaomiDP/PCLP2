#include <iostream> // clasele standard de I/O si cin, cout, ...
#include <fstream> // clasele de lucru cu fisiere ifstream, ofstream
#include <iomanip> // lista tuturor manipulatorilor
#include <conio.h>

using namespace std;
int main( int argc, char *argv[ ] )
{
    if( argc < 3 ) // nu au fost furnizate 2 nume de fisiere
    {
        cout<<"Lansare: "<<argv[0]<<" <input_file> <output_file>"
            <<endl;
        getch();
        return 1;
    }
    ifstream iFile( argv[1], ios::binary ); //Obiect de tipul ifstream
    if( iFile.fail() ) // stabileste daca a esuat deschiderea
    {
        cout<<endl<<"Eroare la deschiderea lui "<<argv[1]<<endl;
        return 2;
    }
    ofstream oFile(argv[2],ios::binary|ios::trunc ); //Obiect ofstream
    if( oFile.fail() ) // stabileste daca a esuat deschiderea
    {
        cout<<endl<<"Eroare la deschiderea lui "<<argv[2]<<endl;
        return 3;
    }
    while( !iFile.eof() )
        oFile<<(char)iFile.get();
    iFile.close();
    oFile.close();
    cout<<"Copiere realizata cu succes!"<<endl;
    getch();
    return 0;
}
