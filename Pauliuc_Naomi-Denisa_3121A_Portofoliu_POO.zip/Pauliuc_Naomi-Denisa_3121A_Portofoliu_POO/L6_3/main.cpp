#include <iostream>

int main(int, char **)
{
    using std::cout;
    using std::endl;
    cout << "Hello World!" << endl;
    return 0;
}
