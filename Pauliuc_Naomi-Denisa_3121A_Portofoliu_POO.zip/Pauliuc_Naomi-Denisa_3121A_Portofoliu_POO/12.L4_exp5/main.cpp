#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int number;
    cout<<"Introduceti un numar : ";
    cin>> number;
    cout << "numar zecima = |" << setw(10)<< number<<"|"<<endl;
    cout.setf(ios::showbase);
    cout << "numar in hexa = |" << setw(10)<< hex << number<<"|"<<endl;
    cout.setf(ios::left);
    cout << "numar in octal, aliniat la stanga = |";
    cout << setfill('.') << setw(10) << oct << number <<"|"<<endl;
}
