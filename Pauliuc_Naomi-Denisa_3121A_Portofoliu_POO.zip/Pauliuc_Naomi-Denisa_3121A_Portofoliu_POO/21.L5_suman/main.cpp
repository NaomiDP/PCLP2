#include <iostream>
#include <stdio.h>
#include <conio.h>
//#define NMAX 10

using namespace std;

int main( void )
{
    int n, s=0, a;
    cout<<"Cate numere vreti sa introduceti: ";
    cin>>n;
    cout<<"\n\n";
    for( int i=0; i < n; i++ )
    {
        cout<<"Int un nr: ";
        cin>>a;
        s=s+a;
    }
    cout<<"Suma numerelor este: "<<s<<endl;
    return 0;
}
