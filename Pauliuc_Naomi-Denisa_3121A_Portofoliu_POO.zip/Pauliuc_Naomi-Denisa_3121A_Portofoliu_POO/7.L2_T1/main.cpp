#include <iostream>
#include <math.h>
#include <conio.h>
#include <stdio.h>      /* printf */
#include <string>

using namespace std;

class Data
{
    int _an, _luna, _zi; // sunt date membre
public:
    void SetData( int an, int luna, int zi); //seteaza datele interne
    void Print( void ); // functie ce printeaza
    int NrZile( Data dc); // calculeaza diferenta de zile re data
// curenta si data stocata la adresa resp.
};

char *luni[]= { "", "IANUARIE", "FEBRUARIE", "MARTIE", "APRILIE",
                "MAI","IUNIE","IULIE","AUGUST","SEPTEMBRIE",
                "OCTOMBRIE", "NOIEMBRIE","DECEMBRIE"
              };

void Data:: SetData( int an, int luna, int zi)
{
    _an = an;
    _luna = luna;
    _zi = zi;
}

void Data::Print( void )
{
    printf("\n%4d %12s %3d", _an, luni[ _luna ], _zi);
}

int Data::NrZile( Data dc) // se considera ca fiecare luna are 30 zile
{
    int nr=0;
    nr += dc._zi >= _zi?dc._zi - _zi:(dc._luna--, 30 + dc._zi - _zi);
    nr += 30 * ( dc._luna >= _luna ? dc._luna - _luna :
                 ( dc._an--, 12 + dc._luna - _luna) );
    nr += 365 * (dc._an - _an); //nr++;
    return nr;
}

int main ( )
{
    //clrscr();
    Data dn, dc; //obiecte apartinand clasei Data
    dn.SetData(2008, 9, 1);
    dc.SetData(2008, 10, 12);
    dn.Print();
    dc.Print();
    printf("\n Nr zile trecute = %d", dn.NrZile( dc ) );
    return 0;
}
