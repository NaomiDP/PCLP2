#include <iostream>

using namespace std;

int main()
{
    int s=0, a, b, c;
    /*double a, b, c;
    double s=0;
    */
    //a
    cout<<"\tInt a: ";
    cin>>a;
    cout<<"\n\n";
    //b
    cout<<"\tInt b: ";
    cin>>b;
    cout<<"\n\n";
    //c
    cout<<"\tInt c: ";
    cin>>c;
    cout<<"\n\n";
    //suma
    s=a+b+c;
    cout<<"\tSuma numerelor introduse este: "<<s<<endl;

    return 0;
}
