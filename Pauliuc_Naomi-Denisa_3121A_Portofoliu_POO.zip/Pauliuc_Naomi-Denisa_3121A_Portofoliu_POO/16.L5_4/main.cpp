#include <iostream>

using namespace std;

char s[ 100 ];
char &f( int );

int main( void )
{
    int n=3;
    for( int i=0; i < n; i++ )
        f( i ) = 'A'; // ~s[i]=�A�;
        cout<<s<<endl;
    return 0;
}

char &f( int ind )
{
    return s[ ind ];
}
