#include <iostream>
#include <string.h>
using namespace std;

#define _DEBUG_ 0

 /*
  * Clasa de baza OBIECT - clasa ABSTARCTA */
class Obiect
{
 protected:
    char nume[20];
 /*
  * Interfata PUBLICA */
 public:
    Obiect( char *p = "( obiect )" )
    {   strncpy( nume, p, 20 );
        if( _DEBUG_ ) cout<<"<CONSTRUCTOR_Ob>: "<<nume<<endl;
    }
    virtual ~Obiect()
    {   if( _DEBUG_ ) cout<<"<DESTRUCTOR_Ob>: "<<nume<<endl;
    }
    virtual void Print( void )
    {   cout << " "<<nume<< " ";
    }
    virtual double Perimetru( void ) = 0;
    virtual double Aria( void ) = 0;
};/* END. Obiect */
 /*
  * Clasa derivata DREPTUNGHI */
class Dreptunghi : public Obiect
{
    double l, L;
    /*
     * Interfata PUBLICA */
 public:
    Dreptunghi( char *p = "( dreptunghi )", double _l=0.0, double _L=0.0 ) :
        Obiect( p ), l( _l ), L( _L )
    {   if( _DEBUG_ ) cout<<"<CONSTRUCTOR_Dr>: "<<nume<< "( "<<l<<", "<<L<<" ) "<<endl;
    }
    ~Dreptunghi( )
    {   if( _DEBUG_ ) cout<<"<DESTRUCTOR_Dr>: "<<nume<< "( "<<l<<", "<<L<<" ) "<<endl;
    }
    void Print( void )
    {   cout << " "<<nume<< "( "<<l<<", "<<L<<" ) ";
    }
    double Perimetru( void )
    {   return 2 * ( l + L );
    }
    double Aria( void )
    {   return l * L;
    }
};/* END. Dreptunghi */
/*
  * Clasa derivata TRIUNGHI */
class Triunghi : public Obiect
{
    double l1, l2, l3;
    /*
     * Interfata PUBLICA */
 public:
    Triunghi( char *p = "( triunghi )", double _l1=0.0, double _l2=0.0, double _l3=0.0 ) :
        Obiect( p ), l1( _l1 ), l2( _l2 ), l3( _l3 )
    {   if( _DEBUG_ ) cout<<"<CONSTRUCTOR_Tr>: "<<nume<< "( "<<l1<<", "<<l2<<", "<<l3<<" ) "<<endl;
    }
    ~Triunghi( )
    {   if( _DEBUG_ ) cout<<"<DESTRUCTOR_Tr>: "<<nume<< "( "<<l1<<", "<<l2<<", "<<l3<<" ) "<<endl;
    }
    void Print( void )
    {   cout << " "<<nume<< "( "<<l1<<", "<<l2<<", "<<l3<<" ) ";
    }
    double Perimetru( void )
    {   return l1 + l2 + l3;
    }
    double Aria( void )
    {
        double p = Perimetru()/2;
        return p*(p-l1)*(p-l2)*(p-l3);
    }
};/* END. Triunghi */

class Stiva
{
    Obiect *lst[100];
    int sp;
 public:
    Stiva( void ) : sp( 0 )
    {   }
    void push( Obiect *val )
    {
        if( sp < sizeof(lst)/sizeof(Obiect*) )
            lst[ sp++ ] = val;
    }
    void pop( void )
    {
        if( sp > 0 )
            sp--;
    }
    Obiect* top( void )
    {
        if( sp > 0 )
            return lst[ sp-1 ];
        return NULL;
    }
};/* END. Stiva */

int main( void )
{
    cout << "[START] Teste\n" << endl;

    cout << "\n(Dreptunghi) ...." << endl;
    Obiect *p1 = new Dreptunghi( "dr_I", 2, 4 );
    p1->Print();
    cout<<"Aria: "<<p1->Aria()<<endl;
    delete p1;

    cout << "\n(Triunghi) ...." << endl;
    Obiect *p2 = new Triunghi( "tr_I", 1, 1, 1 );
    p2->Print();
    cout<<"Aria: "<<p2->Aria()<<endl;
    delete p2;

    cout << "\n[START] Stiva heterogena\n" << endl;
    Stiva S;

    Triunghi    ob1( "TRIUNGHI I", 2, 2, 2 );
    Dreptunghi  ob2( "DREPTUNGHI I", 2, 3 );
    Obiect      *ob;

    (&ob1)->Print();   cout<<"Aria: "<<(&ob1)->Aria()<<endl;
    S.push( (&ob1) );  cout<<"\tPUSH"<<endl;
    (&ob2)->Print();   cout<<"Aria: "<<(&ob2)->Aria()<<endl;
    S.push( (&ob2) );  cout<<"\tPUSH"<<endl;

    cout<<"\n ........................"<<endl;
    ob = S.top();   cout<<"\tTOP"<<endl;
    ob->Print();    cout<<"Aria: "<<ob->Aria()<<endl;
    S.pop();        cout<<"\tPOP"<<endl;
    ob = S.top();   cout<<"\tTOP"<<endl;
    ob->Print(); cout<<"Aria: "<<ob->Aria()<<endl;

    return 0;
}
