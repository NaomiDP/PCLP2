//
//  ViewController.swift
//  ANA_3142B
//
//  Created by st1.c204 on 25/11/2022.
//  Copyright © 2022 st1.c204. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var infoBtn: UIButton!
    
}

